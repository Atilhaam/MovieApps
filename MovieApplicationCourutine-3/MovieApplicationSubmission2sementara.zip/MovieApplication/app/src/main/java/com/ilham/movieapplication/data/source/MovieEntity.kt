package com.ilham.movieapplication.data.source

data class MovieEntity(
        var movieId: String,
        var title: String,
        var description: String,
        var director: String,
        var realeaseDate: String,
        var poster: String,
)
