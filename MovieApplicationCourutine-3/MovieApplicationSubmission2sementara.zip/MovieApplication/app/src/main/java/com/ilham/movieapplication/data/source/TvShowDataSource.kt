package com.ilham.movieapplication.data.source

interface TvShowDataSource {
    fun getAllTvShow() : List<TvShowEntity>
}