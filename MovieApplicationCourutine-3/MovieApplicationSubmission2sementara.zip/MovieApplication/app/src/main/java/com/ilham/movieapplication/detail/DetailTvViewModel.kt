package com.ilham.movieapplication.detail

import androidx.lifecycle.ViewModel
import com.ilham.movieapplication.data.source.TvShowEntity
import com.ilham.movieapplication.data.source.TvShowRepository

class DetailTvViewModel(private val tvShowRepository: TvShowRepository) : ViewModel() {
    private lateinit var tvId: String

    fun setSelectedTv(tvId: String) {
        this.tvId = tvId
    }
    fun getTvShows() : TvShowEntity {
        lateinit var tvShow: TvShowEntity
        val tvShowEntities = tvShowRepository.getAllTvShow()
        for (tvShowEntity in tvShowEntities) {
            if (tvShowEntity.tvId == tvId) {
                tvShow = tvShowEntity
            }
        }
        return tvShow
    }
}