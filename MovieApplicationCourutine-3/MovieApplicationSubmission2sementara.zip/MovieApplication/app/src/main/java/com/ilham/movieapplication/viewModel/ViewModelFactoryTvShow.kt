package com.ilham.movieapplication.viewModel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.ilham.movieapplication.data.source.TvShowRepository
import com.ilham.movieapplication.detail.DetailTvViewModel
import com.ilham.movieapplication.di.Injection
import com.ilham.movieapplication.tv.TvViewModel

class ViewModelFactoryTvShow private constructor(private val mTvShowRepository: TvShowRepository) : ViewModelProvider.NewInstanceFactory() {

    companion object {
        @Volatile
        private var instance: ViewModelFactoryTvShow? = null

        fun getInstance(context: Context): ViewModelFactoryTvShow =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactoryTvShow(Injection.provideRepositoryTvShow(context)).apply {
                    instance = this
                }
            }
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        when {
            modelClass.isAssignableFrom(TvViewModel::class.java) -> {
                return TvViewModel(mTvShowRepository) as T
            }
            modelClass.isAssignableFrom(DetailTvViewModel::class.java) -> {
                return DetailTvViewModel(mTvShowRepository) as T
            }
            else -> throw Throwable("Unknown ViewModel class: " + modelClass.name)
        }
    }
}