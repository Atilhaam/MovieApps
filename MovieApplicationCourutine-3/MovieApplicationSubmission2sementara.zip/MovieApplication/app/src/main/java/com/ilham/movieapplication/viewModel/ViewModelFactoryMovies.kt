package com.ilham.movieapplication.viewModel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.ilham.movieapplication.data.source.MovieRepository
import com.ilham.movieapplication.detail.DetailMovieViewModel
import com.ilham.movieapplication.di.Injection
import com.ilham.movieapplication.movie.MovieViewModel

class ViewModelFactoryMovies private constructor(private val mMovieRepository: MovieRepository) : ViewModelProvider.NewInstanceFactory() {

    companion object {
        @Volatile
        private var instance: ViewModelFactoryMovies? = null

        fun getInstance(context: Context): ViewModelFactoryMovies =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactoryMovies(Injection.provideRepositoryMovies(context)).apply {
                    instance = this
                }
            }
    }

    @Suppress("UNCHECKED_CAST")
    override fun  <T : ViewModel> create(modelClass: Class<T>): T {
        when {
            modelClass.isAssignableFrom(MovieViewModel::class.java) -> {
                return MovieViewModel(mMovieRepository) as T
            }
            modelClass.isAssignableFrom(DetailMovieViewModel::class.java) -> {
                return DetailMovieViewModel(mMovieRepository) as T
            }
            else -> throw Throwable("Unknown ViewModel class: " + modelClass.name)
        }
    }
}