package com.ilham.movieapplication.data.source.remote.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TvResponse(
    var tvId: String,
    var title: String,
    var description: String,
    var creator: String,
    var releaseDate: String,
    var poster: String
) : Parcelable
