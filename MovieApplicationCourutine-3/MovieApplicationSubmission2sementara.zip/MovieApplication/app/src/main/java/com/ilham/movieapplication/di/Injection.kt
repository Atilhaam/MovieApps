package com.ilham.movieapplication.di

import android.content.Context
import com.ilham.movieapplication.data.source.MovieRepository
import com.ilham.movieapplication.data.source.TvShowRepository
import com.ilham.movieapplication.data.source.remote.RemoteDataSource
import com.ilham.movieapplication.utils.JsonHelper

object Injection {
    fun provideRepositoryMovies(context: Context) : MovieRepository {

        val remoteDataSource = RemoteDataSource.getInstance(JsonHelper(context))

        return MovieRepository.getInstance(remoteDataSource)
    }
    fun provideRepositoryTvShow(context: Context) : TvShowRepository {

        val remoteDataSource = RemoteDataSource.getInstance(JsonHelper(context))

        return TvShowRepository.getInstance(remoteDataSource)
    }
}