package com.ilham.movieapplication.data.source

import com.ilham.movieapplication.data.source.remote.RemoteDataSource

class MovieRepository private constructor(private val remoteDataSource: RemoteDataSource) : MovieDataSource{

    companion object {
        @Volatile
        private var instance: MovieRepository? = null

        fun getInstance(remoteData: RemoteDataSource) : MovieRepository =
            instance ?: synchronized(this) {
                instance ?: MovieRepository(remoteData).apply { instance = this }
            }
    }

    override fun getAllMovies(): ArrayList<MovieEntity> {
        val movieResponse = remoteDataSource.getAllMovies()
        val movieList = ArrayList<MovieEntity>()
        for (response in movieResponse) {
            val movie = MovieEntity(response.movieId,
            response.title,
            response.description,
            response.director,
            response.realeaseDate,
            response.poster)

            movieList.add(movie)
        }
        return movieList
    }
}