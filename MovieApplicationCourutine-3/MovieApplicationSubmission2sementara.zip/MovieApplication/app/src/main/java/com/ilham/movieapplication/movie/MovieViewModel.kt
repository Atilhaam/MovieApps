package com.ilham.movieapplication.movie

import androidx.lifecycle.ViewModel
import com.ilham.movieapplication.data.source.MovieEntity
import com.ilham.movieapplication.data.source.MovieRepository

class MovieViewModel(private val movieRepository: MovieRepository) : ViewModel() {

    fun getMovies(): List<MovieEntity> = movieRepository.getAllMovies()
}