package com.ilham.movieapplication

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.ilham.movieapplication.data.source.TvShowEntity
import com.ilham.movieapplication.databinding.ItemsMovieBinding
import com.ilham.movieapplication.detail.DetailTvActivity

class TvAdapter : RecyclerView.Adapter<TvAdapter.TvViewHolder>(){
    private var listTv = ArrayList<TvShowEntity>()

    fun setTvShow(tv: List<TvShowEntity>) {
        if (tv == null) return
        this.listTv.clear()
        this.listTv.addAll(tv)
    }
    class TvViewHolder(private val binding: ItemsMovieBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tv: TvShowEntity) {
            with(binding) {
                tvItemTitle.text = tv.title
                tvItemDescription.text = tv.description
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailTvActivity::class.java)
                    intent.putExtra(DetailTvActivity.EXTRA_TV, tv.tvId)
                    itemView.context.startActivity(intent)
                }
                Glide.with(itemView.context)
                    .load("https://image.tmdb.org/t/p/original/${tv.poster}")
                    .centerCrop()
                    .into(imgPoster)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvViewHolder {
        val itemTvBinding = ItemsMovieBinding.inflate(LayoutInflater.from(parent.context))
        return TvViewHolder(itemTvBinding)
    }

    override fun onBindViewHolder(holder: TvViewHolder, position: Int) {
        val tv = listTv[position]
        holder.bind(tv)
    }

    override fun getItemCount(): Int {
        return listTv.size
    }
}