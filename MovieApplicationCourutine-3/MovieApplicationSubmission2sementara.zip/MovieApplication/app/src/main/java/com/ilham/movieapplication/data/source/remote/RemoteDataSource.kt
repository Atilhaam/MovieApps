package com.ilham.movieapplication.data.source.remote

import com.ilham.movieapplication.data.source.remote.response.MovieResponse
import com.ilham.movieapplication.data.source.remote.response.TvResponse
import com.ilham.movieapplication.utils.JsonHelper

class RemoteDataSource private constructor(private val jsonHelper: JsonHelper) {
    companion object {
        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(helper: JsonHelper): RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource(helper).apply { instance = this }
            }
    }

    fun getAllMovies() : List<MovieResponse> = jsonHelper.loadMovies()

    fun getAllTvShow() : List<TvResponse> = jsonHelper.loadTvShow()
}