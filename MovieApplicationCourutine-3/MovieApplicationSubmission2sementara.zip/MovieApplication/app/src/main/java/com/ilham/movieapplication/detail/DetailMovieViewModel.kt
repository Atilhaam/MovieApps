package com.ilham.movieapplication.detail

import androidx.lifecycle.ViewModel
import com.ilham.movieapplication.data.source.MovieEntity
import com.ilham.movieapplication.data.source.MovieRepository

class DetailMovieViewModel(private val movieRepository: MovieRepository) : ViewModel() {
    private lateinit var movieId: String

    fun setSelectedMovie(movieId: String) {
        this.movieId = movieId
    }
    fun getMovies() : MovieEntity {
        lateinit var movie: MovieEntity
        val movieEntities = movieRepository.getAllMovies()
        for (movieEntity in movieEntities) {
            if (movieEntity.movieId == movieId) {
                movie = movieEntity
            }
        }
        return movie
    }
}