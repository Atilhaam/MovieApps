package com.ilham.movieapplication.data.source

interface MovieDataSource {
    fun getAllMovies() : List<MovieEntity>
}