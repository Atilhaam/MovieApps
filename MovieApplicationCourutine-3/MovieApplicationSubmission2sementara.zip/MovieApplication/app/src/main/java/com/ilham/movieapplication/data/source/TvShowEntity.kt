package com.ilham.movieapplication.data.source

data class TvShowEntity(
        var tvId: String,
        var title: String,
        var description: String,
        var creator: String,
        var realeaseDate: String,
        var poster: String,
)
