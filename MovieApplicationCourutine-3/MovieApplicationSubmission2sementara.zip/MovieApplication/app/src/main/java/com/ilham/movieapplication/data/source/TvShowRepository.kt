package com.ilham.movieapplication.data.source

import com.ilham.movieapplication.data.source.remote.RemoteDataSource

class TvShowRepository private constructor(private val remoteDataSource: RemoteDataSource) : TvShowDataSource {
    companion object {
        @Volatile
        private var instance: TvShowRepository? = null

        fun getInstance(remoteData: RemoteDataSource) : TvShowRepository =
            instance ?: synchronized(this) {
                instance ?: TvShowRepository(remoteData).apply { instance = this }
            }
    }

    override fun getAllTvShow(): ArrayList<TvShowEntity> {
        val tvResponse = remoteDataSource.getAllTvShow()
        val tvShowList = ArrayList<TvShowEntity>()
        for (response in tvResponse) {
            val tvShow = TvShowEntity(response.tvId,
                response.title,
                response.description,
                response.creator,
                response.releaseDate,
                response.poster)
            tvShowList.add(tvShow)
        }
        return tvShowList
    }

}