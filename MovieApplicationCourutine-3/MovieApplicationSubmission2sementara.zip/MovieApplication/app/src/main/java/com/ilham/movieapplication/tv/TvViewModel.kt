package com.ilham.movieapplication.tv

import androidx.lifecycle.ViewModel
import com.ilham.movieapplication.data.source.TvShowEntity
import com.ilham.movieapplication.data.source.TvShowRepository

class TvViewModel(private val tvShowRepository: TvShowRepository) : ViewModel() {

    fun getTvShows() : List<TvShowEntity> = tvShowRepository.getAllTvShow()
}