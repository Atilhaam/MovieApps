package com.ilham.movieapplication.tv

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.ilham.movieapplication.MovieAdapter
import com.ilham.movieapplication.R
import com.ilham.movieapplication.TvAdapter
import com.ilham.movieapplication.databinding.FragmentMovieBinding
import com.ilham.movieapplication.databinding.FragmentTvBinding
import com.ilham.movieapplication.viewModel.ViewModelFactoryTvShow


class TvFragment : Fragment() {
    private lateinit var fragmentTvBinding: FragmentTvBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        fragmentTvBinding = FragmentTvBinding.inflate(layoutInflater, container, false)
        return fragmentTvBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            val factory = ViewModelFactoryTvShow.getInstance(requireActivity())
            val viewModel = ViewModelProvider(this, factory)[TvViewModel::class.java]
            val tv = viewModel.getTvShows()
            val tvAdapter = TvAdapter()
            tvAdapter.setTvShow(tv)

            with(fragmentTvBinding.rvTv) {
                layoutManager = LinearLayoutManager(context)
                setHasFixedSize(true)
                adapter = tvAdapter
            }
        }
    }


}