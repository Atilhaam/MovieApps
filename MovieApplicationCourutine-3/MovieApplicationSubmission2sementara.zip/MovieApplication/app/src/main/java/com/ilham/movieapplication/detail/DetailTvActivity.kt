package com.ilham.movieapplication.detail

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.ilham.movieapplication.data.source.TvShowEntity
import com.ilham.movieapplication.databinding.ActivityDetailTvBinding
import com.ilham.movieapplication.databinding.ContentDetailTvBinding
import com.ilham.movieapplication.viewModel.ViewModelFactoryTvShow

class DetailTvActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_TV = "extra_tv"
    }

    private lateinit var detailContentBinding : ContentDetailTvBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activityDetailTvBinding = ActivityDetailTvBinding.inflate(layoutInflater)
        detailContentBinding = activityDetailTvBinding.detailContent

        setContentView(activityDetailTvBinding.root)

        setSupportActionBar(activityDetailTvBinding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactoryTvShow.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[DetailTvViewModel::class.java]

        val extras = intent.extras
        if (extras != null) {
            val tvId = extras.getString(EXTRA_TV)
            if (tvId != null) {
                viewModel.setSelectedTv(tvId)
                populateTv(viewModel.getTvShows() as TvShowEntity)
            }
        }
    }

    private fun populateTv(tvEntity: TvShowEntity) {
        detailContentBinding.textTitle.text = tvEntity.title
        detailContentBinding.textDate.text = tvEntity.realeaseDate
        detailContentBinding.textDescription.text = tvEntity.description
        detailContentBinding.textDirector.text = tvEntity.creator

        Glide.with(this)
            .load("https://image.tmdb.org/t/p/original/${tvEntity.poster}")
            .centerCrop()
            .into(detailContentBinding.imagePoster)
    }
}