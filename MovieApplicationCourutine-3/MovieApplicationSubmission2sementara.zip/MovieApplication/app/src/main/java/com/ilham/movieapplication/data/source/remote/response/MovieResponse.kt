package com.ilham.movieapplication.data.source.remote.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MovieResponse (
    var movieId: String,
    var title: String,
    var description: String,
    var director: String,
    var realeaseDate: String,
    var poster: String
        ) : Parcelable