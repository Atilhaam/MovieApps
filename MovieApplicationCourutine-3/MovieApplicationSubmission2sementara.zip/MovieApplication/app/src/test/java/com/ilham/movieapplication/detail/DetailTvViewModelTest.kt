package com.ilham.movieapplication.detail

import com.ilham.movieapplication.utils.DataDummy
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class DetailTvViewModelTest {
    private lateinit var viewModel: DetailTvViewModel
    private val dummyTvShow = DataDummy.generateDummyTvShow()[0]
    private val tvId = dummyTvShow.tvId

    @Before
    fun setUp() {
        viewModel = DetailTvViewModel()
        viewModel.setSelectedTv(tvId)
    }

    @Test
    fun setSelectedTv() {
    }

    @Test
    fun getTvShows() {
        viewModel.setSelectedTv(dummyTvShow.tvId)
        val tvEntity = viewModel.getTvShows()
        assertNotNull(tvEntity)
        assertEquals(dummyTvShow.poster, tvEntity.poster)
        assertEquals(dummyTvShow.creator, tvEntity.creator)
        assertEquals(dummyTvShow.description, tvEntity.description)
        assertEquals(dummyTvShow.realeaseDate, tvEntity.realeaseDate)
        assertEquals(dummyTvShow.title, tvEntity.title)
        assertEquals(dummyTvShow.tvId, tvEntity.tvId)
    }
}